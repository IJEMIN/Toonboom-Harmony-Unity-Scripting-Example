#include "XML_StageSaxParser.h"
#include "XML_ProjectLoader.h"

#include "Tree/TR_NodeTree.h"
#include "Tree/TR_NodeTreeBuilder.h"

#include "Render/RD_ClipDataCore.h"

#include "Base/STD_Types.h"

#include <string.h>

//  Common tags
#define kNameTag               "name"
#define kFilenameTag           "filename"
#define kRepeatTag             "repeat"
#define kTimeTag               "time"

//  Stage group main tags
#define kStageColTag           "stages"
#define kStageTag              "stage"
#define kPropColTag            "props"
#define kPlayTag               "play"
#define kMetaTag               "meta"
#define kPropTag               "prop"
#define kAnchorTag             "anchor"
#define kSoundTag              "sound"
#define kSkinTag               "skin"
#define kSkinIdTag             "skinId"
#define kGroupTag              "group"
#define kGroupIdTag            "groupId"

#define kParentSkeletonTag     "parent"
#define kParentBoneTag         "bone"
#define kValueTag              "value"

//  Stage group variable tags
#define kSkeletonColTag        "skeletons"
#define kSkeletonTag           "skeleton"
#define kNodeColTag            "nodes"
#define kNodeTag               "node"
#define kPegTag                "peg"
#define kReadTag               "read"
#define kLinkColTag            "links"
#define kLinkTag               "link"

#define kAnimationTag          "animation"
#define kDrawingAnimationTag   "drawingAnimation"

#define kDrawingTag            "drw"
#define kDrawingIdTag          "drwId"

#define kTimeTag               "time"
#define kParentSkeletonTag     "parent"
#define kParentBoneTag         "bone"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - XML_StageSaxParser
#endif

XML_StageSaxParser::XML_StageSaxParser( const STD_String &projectFolder, const STD_String &clipName, RD_ClipDataCore *clip ) :
  _projectFolder(projectFolder),
  _state(eRoot),
  _clip(clip)
{
	_clip->_clipName = clipName;
  _clip->beginClipData();
}

XML_StageSaxParser::~XML_StageSaxParser()
{
  _clip->endClipData();
}

XML_SaxParserComponentPtr_t XML_StageSaxParser::startComponent(const char *nodeName, const XML_AttributeCol_t &attributes)
{
  if ( _state == eRoot )
  {
    if ( strcmp( nodeName, kStageColTag ) == 0 )
    {
      _state = eStages;
    }
  }
  else if ( _state == eStages )
  {
    if ( (strcmp( nodeName, kStageTag ) == 0) ||
         (strcmp( nodeName, kPropColTag ) == 0) )
    {
      //  Only enter stage mode if we encounter the xml tag we search for.
      STD_String value;
      if (findAttribute( attributes, kNameTag, value ) && (value.compare(_clip->_clipName) == 0))
      {
        _state = eStage;
      }
    }
  }
  else // if ( _state == eStage )
  {
    if ( (strcmp( nodeName, kPlayTag ) == 0) ||
         (strcmp( nodeName, kPropTag ) == 0) )
    {
      TR_NodeTree *nodeTree = new TR_NodeTree;

      STD_String value;
      if (findAttribute(attributes, kSkeletonTag, value))
      {
        XML_ProjectLoader::loadSkeleton(_projectFolder, value, nodeTree);
      }
      if (findAttribute(attributes, kAnimationTag, value))
      {
        XML_ProjectLoader::loadAnimation(_projectFolder, value, nodeTree);
      }
      if (findAttribute(attributes, kDrawingAnimationTag, value))
      {
        XML_ProjectLoader::loadDrawingAnimation(_projectFolder, value, nodeTree);
      }

      STD_String playName;
      findAttribute(attributes, kNameTag, playName);

      //nodeTree->dump();
      _clip->addNodeTree(nodeTree, playName );
    }
    else if ( strcmp( nodeName, kSoundTag ) == 0 )
    {
      float startFrame = 1.0f; // default at first frame.
      STD_String soundName;

      STD_String value;
      if (findAttribute(attributes, kNameTag, value))
      {
        soundName = value;
      }
      if (findAttribute(attributes, kTimeTag, value))
      {
        startFrame = (float)atof(value.c_str());
      }

      _clip->addSoundEvent(soundName, startFrame);
    }
  }

  return this;
}

void XML_StageSaxParser::endComponent(const char *nodeName)
{
  if ( strcmp( nodeName, kStageTag ) == 0 || strcmp(nodeName, kPropColTag) == 0)
  {
    _state = eStages;
  }
  else if ( strcmp( nodeName, kStageColTag ) == 0 )
  {
    _state = eRoot;
  }
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - XML_StageNamesSaxParser
#endif

XML_StageNamesSaxParser::XML_StageNamesSaxParser( const STD_String &projectFolder, ClipDataCol_t &clipData ) :
  _projectFolder(projectFolder),
  _state(eRoot),
  _clipData(clipData)
{
}

XML_StageNamesSaxParser::~XML_StageNamesSaxParser()
{
}

XML_SaxParserComponentPtr_t XML_StageNamesSaxParser::startComponent(const char *nodeName, const XML_AttributeCol_t &attributes)
{
  if ( _state == eRoot )
  {
    if ( strcmp( nodeName, kStageColTag ) == 0 )
    {
      _state = eStages;
    }
  }
  else if ( _state == eStages )
  {
    if ( strcmp( nodeName, kStageTag ) == 0 )
    {
      //  Only enter stage mode if we encounter the xml tag we search for.
      if (findAttribute( attributes, kNameTag, _parentName))
      {
        _state = eStage;
      }
    }
    else if (strcmp(nodeName, kPropColTag) == 0)
    {
        //  Only enter stage mode if we encounter the xml tag we search for.
        if (findAttribute(attributes, kNameTag, _parentName))
        {
            _state = eProps;
        }
    }
  }
  else if (_state == eStage)
  {
      if (strcmp(nodeName, kPlayTag) == 0)
      {
          STD_String animationName;
          STD_String name;
          if (findAttribute(attributes, kAnimationTag, animationName))
          {
              findAttribute(attributes, kNameTag, name);
              _clipData.push_back({ _parentName, _parentName, name, false });
          }
      }
  }
  else if (_state == eProps)
  {
      if (strcmp(nodeName, kPropTag) == 0)
      {
          STD_String name;
          if (findAttribute(attributes, kNameTag, name))
          {
              _clipData.push_back({ name, name, _parentName, true });
          }
      }
  }

  return this;
}

void XML_StageNamesSaxParser::endComponent(const char *nodeName)
{
  if ( strcmp( nodeName, kStageTag ) == 0 )
  {
    _state = eStages;
  }
  else if ( strcmp( nodeName, kStageColTag ) == 0 )
  {
    _state = eRoot;
  }
  else if (strcmp(nodeName, kPropColTag) == 0)
  {
      _state = eStages;
  }
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - XML_SkinsNamesSaxParser
#endif

XML_SkinsNamesSaxParser::XML_SkinsNamesSaxParser(const STD_String& projectFolder, HarmonyNodeCol_t& nodes, HarmonyIdCol_t& skinNames, HarmonyIdCol_t& groupNames) :
    _projectFolder(projectFolder),
    _state(eRoot),
    _nodes(nodes),
    _skinNames(skinNames),
    _groupNames(groupNames)
{
}

XML_SkinsNamesSaxParser::~XML_SkinsNamesSaxParser()
{
}

XML_SaxParserComponentPtr_t XML_SkinsNamesSaxParser::startComponent(const char* nodeName, const XML_AttributeCol_t& attributes)
{
    if (_state == eRoot)
    {
        if (strcmp(nodeName, kStageColTag) == 0)
        {
            _state = eStages;
        }
    }
    else if (_state == eStages)
    {
        if (strcmp(nodeName, kStageTag) == 0)
        {
            //  Only enter stage mode if we encounter the xml tag we search for.
            STD_String clipName;
            if (findAttribute(attributes, kNameTag, clipName))
            {
                _state = eStage;
            }
        }
    }
    else if (_state == eStage)
    {
        if (strcmp(nodeName, kNodeTag) == 0)
        {
            //Name
            STD_String name = "";
            findAttribute(attributes, kNameTag, name);

            //Skin Ids
            STD_String skinIdsStr = "";
            findAttribute(attributes, kSkinIdTag, skinIdsStr);

            STD_Vector<int> skinIds = STD_Vector<int>();
            STD_Stringstream skinIdsStrStream(skinIdsStr);
            STD_String segment;

            while (std::getline(skinIdsStrStream, segment, ','))
            {
                skinIds.push_back(STD_stoi(segment));
            }

            //GroupId
            STD_String idStr = "";
            findAttribute(attributes, kGroupIdTag, idStr);
            int groupId = STD_stoi(idStr);

            //Id
            findAttribute(attributes, kDrawingIdTag, idStr);
            int id = STD_stoi(idStr);

            _nodes.push_back({ skinIds, name, groupId, id });
        }
        else if (strcmp(nodeName, kSkinTag) == 0)
        {
            STD_String name = "";
            findAttribute(attributes, kNameTag, name);

            STD_String idStr = "";
            findAttribute(attributes, kSkinIdTag, idStr);
            int id = STD_stoi(idStr);
            _skinNames.push_back({ id, name });
        }
        else if (strcmp(nodeName, kGroupTag) == 0)
        {
            STD_String name = "";
            findAttribute(attributes, kNameTag, name);

            STD_String idStr = "";
            findAttribute(attributes, kGroupIdTag, idStr);
            int id = STD_stoi(idStr);
            _groupNames.push_back({ id, name });
        }
    }

    return this;
}

void XML_SkinsNamesSaxParser::endComponent(const char* nodeName)
{
    if (strcmp(nodeName, kStageTag) == 0)
    {
        _state = eStages;
    }
    else if (strcmp(nodeName, kStageColTag) == 0)
    {
        _state = eRoot;
    }
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - XML_MetaSaxParserComponent
#endif

XML_MetaSaxParserComponent::XML_MetaSaxParserComponent(const STD_String& projectFolder, StringPairsCol_t& props, StringPairsCol_t& anchors, GenericMetaCol_t& metas) :
    _projectFolder(projectFolder),
    _state(eRoot),
    _props(props),
    _anchors(anchors),
    _metas(metas)
{
}

XML_MetaSaxParserComponent::~XML_MetaSaxParserComponent()
{
}

XML_SaxParserComponentPtr_t XML_MetaSaxParserComponent::startComponent(const char* nodeName, const XML_AttributeCol_t& attributes)
{
    if (_state == eRoot)
    {
        if (strcmp(nodeName, kStageColTag) == 0)
        {
            _state = eStages;
        }
    }
    else if (_state == eStages)
    {
        if (strcmp(nodeName, kStageTag) == 0 ||
            strcmp(nodeName, kPropColTag) == 0)
        {
            //  Only enter stage mode if we encounter the xml tag we search for.
            _clipName;
            if (findAttribute(attributes, kNameTag, _clipName))
            {
                _state = eStage;
            }
        }
    }
    else if (_state == eStage)
    {
        if (strcmp(nodeName, kPropTag) == 0)
        {
            STD_String playName = "";
            if (findAttribute(attributes, kNameTag, playName))
            {
                _props.push_back({ _clipName, playName });
            }
        }
        else if (strcmp(nodeName, kAnchorTag) == 0)
        {
            STD_String nodeName = "";
            STD_String playName = "";
            if (findAttribute(attributes, kNodeTag, nodeName) &&
                findAttribute(attributes, kPlayTag, playName))
            {
                _anchors.push_back({ playName, nodeName });
            }
        }
        else if (strcmp(nodeName, kMetaTag) == 0)
        {
            STD_String name = "";
            STD_String playName = "";
            STD_String nodeName = "";
            STD_String value = "";
            if (findAttribute(attributes, kNameTag, name))
            {
                bool gotValue = findAttribute(attributes, kValueTag, value);
                bool gotNodename = findAttribute(attributes, kNodeTag, nodeName);
                bool gotPlayname = findAttribute(attributes, kPlayTag, playName);
                _metas.push_back({ name, _clipName, gotPlayname ? playName : "", gotNodename ? nodeName : "", gotValue ? value : "" });
            }
        }
    }

    return this;
}

void XML_MetaSaxParserComponent::endComponent(const char* nodeName)
{
    if (strcmp(nodeName, kStageTag) == 0)
    {
        _state = eStages;
    }
    else if (strcmp(nodeName, kStageColTag) == 0)
    {
        _state = eRoot;
    }
}

