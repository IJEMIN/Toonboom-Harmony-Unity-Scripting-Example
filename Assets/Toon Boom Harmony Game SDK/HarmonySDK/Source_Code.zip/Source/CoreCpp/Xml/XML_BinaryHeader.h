#ifndef _XML_BINARY_HEADER_H_
#define _XML_BINARY_HEADER_H_

#include "Base/IO_PersistentStore.h"
#include <cstdint>

struct  XML_BinaryHeader
{
	int32_t magicbyte = 0x66626274;
	int32_t majorVersion = 2;
	int32_t minorVersion = 0;
	int32_t pad0 = 0;

	int64_t clipSize = 0;
	int64_t clipOffset = 0;
	int64_t sheetSize = 0;
	int64_t sheetOffset = 0;

	int64_t nodeSize = 0;
	int64_t nodeOffset = 0;
	int64_t skinsSize = 0;
	int64_t skinsOffset = 0;

	int64_t groupSize = 0;
	int64_t groupOffset = 0;
	int64_t fullClipSize = 0;
	int64_t fullClipOffset = 0;

	int64_t fullSheetSize = 0;
	int64_t fullSheetOffset = 0;
	int64_t propsSize = 0;
	int64_t propsOffset = 0;

	int64_t anchorsSize = 0;
	int64_t anchorsOffset = 0;
	int64_t metasSize = 0;
	int64_t metasOffset = 0;

	int64_t singleSpritesSize = 0;
	int64_t singleSpritesOffset = 0;


	void store(IO_PersistentStore& store);
	void read(IO_PersistentStore& store);
};

#endif