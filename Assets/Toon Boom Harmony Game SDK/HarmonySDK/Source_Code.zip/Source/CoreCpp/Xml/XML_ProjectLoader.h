#ifndef _XML_PROJECT_LOADER_H_
#define _XML_PROJECT_LOADER_H_

#include "Base/MEM_Override.h"
#include "Base/STD_Containers.h"
#include "Base/STD_Types.h"
#include "XML_StageSaxParser.h"
#include "XML_SpriteSheetSaxParser.h"

#include <string>

class TR_NodeTree;
class RD_ClipDataCore;
class RD_SpriteSheetCore;

/*!
 *  @namespace XML_ProjectLoader
 */
namespace XML_ProjectLoader
{
  typedef STD_Vector< STD_String > StringCol_t;

  typedef STD_Pair< STD_String, STD_String > StringPair_t;
  typedef STD_Vector< StringPair_t > StringPairCol_t;

  typedef STD_Pair< STD_String, float > SoundEvent_t;
  typedef STD_Vector< SoundEvent_t > SoundEventCol_t;

  typedef STD_Vector< XML_StageNamesSaxParser::ClipData > ClipDataCol_t;

  typedef STD_Vector< XML_SkinsNamesSaxParser::HarmonyNode > HarmonyNodeCol_t;
  typedef STD_Vector< STD_Pair<int, STD_String> > HarmonyIdCol_t;

  typedef STD_Vector< STD_Pair< STD_String, STD_String > > StringPairsCol_t;
  typedef STD_Vector< XML_MetaSaxParserComponent::GenericMeta > GenericMetaCol_t;

  //! Build a list of all stage clips in specified project folder.
  void loadStageClipNames( const STD_String &projectFolder, ClipDataCol_t &clipNames );
  //! Build lists of nodes, skins and groups in project folder
  void loadSkinNames(const STD_String& projectFolder, HarmonyNodeCol_t& nodes, HarmonyIdCol_t& skinNames, HarmonyIdCol_t& groupNames);
  //! Build lists of props, anchors and metas in project folder
  void loadMetas(const STD_String& projectFolder, StringPairsCol_t& props, StringPairsCol_t& anchors, GenericMetaCol_t& metas);

  //! Load specified stage clip to clip data structure.
  void loadStageClip( const STD_String &projectFolder, const STD_String &clipName, RD_ClipDataCore *clip );
  //! Load specified skeleton and append to node tree.
  void loadSkeleton( const STD_String &projectFolder, const STD_String &skeletonName, TR_NodeTree *nodeTree );
  //! Load specified animation and append to node tree.
  void loadAnimation( const STD_String &projectFolder, const STD_String &animationName, TR_NodeTree *nodeTree );
  //! Load specified drawing animation and append to node tree.
  void loadDrawingAnimation( const STD_String &projectFolder, const STD_String &drawingAnimationName, TR_NodeTree *nodeTree );

  //! Build a list of all sprite sheet names in specified project folder.
  void loadSpriteSheetNames( const STD_String &projectFolder, StringPairCol_t &sheetNames );
  //! Build a list of all sprite sheet resolution names for specified sprite sheet.
  void loadSpriteSheetResolutionNames( const STD_String &projectFolder, const STD_String &sheetName, StringPairCol_t &resolutionNames );

  //! Load specified sprite sheet with sheet resolution to sprite sheet data structure.
  void loadSpriteSheet( const STD_String &projectFolder, const STD_String &sheetName, const STD_String &sheetResolution, RD_SpriteSheetCore *sheet );
  //! Load specified sprite sheet with default sheet resolution to sprite sheet data structure.
  void loadSpriteSheet( const STD_String &projectFolder, const STD_String &sheetName, RD_SpriteSheetCore *sheet );
  //! Checks whether or not the project has spritesheets.
  bool hasSpriteSheet(const STD_String& projectFolder);
  //! Load an individual sprite xml file.
  void loadSprite(const STD_String& spritePath, XML_SpritesSaxParser::CropInfo* cropInfo);
  //! Load sprite xml files from when exported individually.
  void loadSprites(const STD_String& projectFolder, STD_Vector<XML_SpritesSaxParser::CropInfo> &cropInfoCol);

}

#endif /* _XML_PROJECT_LOADER_H_ */
