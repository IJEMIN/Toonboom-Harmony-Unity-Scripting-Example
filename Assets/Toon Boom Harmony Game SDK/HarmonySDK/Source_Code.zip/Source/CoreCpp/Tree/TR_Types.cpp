#include "TR_Types.h"

int TR_Types::g_nullOffset = -1;
