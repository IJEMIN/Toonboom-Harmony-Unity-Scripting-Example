
#include "PL_Atomic.h"
#include "PL_Mutex.h"

#if !defined(SUPPORT_CXX11_STANDARD) && defined(TARGET_WIN32)

#include <windows.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - PL_AtomicInt32::Impl
#endif
class PL_AtomicInt32::Impl
{
  friend class PL_AtomicInt32;

public:

  Impl()
  {
  }

  ~Impl()
  {
  }

private:
  LONG _value;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - PL_AtomicInt32
#endif

PL_AtomicInt32::PL_AtomicInt32()
{
  _i = new Impl;
  _i->_value = 0;
}

PL_AtomicInt32::PL_AtomicInt32(int32_t value)
{
  _i = new Impl;
  _i->_value = (LONG)value;
}

PL_AtomicInt32::~PL_AtomicInt32()
{
  delete _i;
}

int32_t PL_AtomicInt32::operator++()
{
  return (int32_t)InterlockedIncrement( &_i->_value );
}

int32_t PL_AtomicInt32::operator++(int)
{
  LONG ret = InterlockedIncrement(&_i->_value);
  return (int32_t)(ret-1);
}

int32_t PL_AtomicInt32::operator--()
{
  return (int32_t)InterlockedDecrement( &_i->_value );

}

int32_t PL_AtomicInt32::operator--(int)
{
  LONG ret = InterlockedDecrement(&_i->_value);
  return (int32_t)(ret-1);
}

int32_t PL_AtomicInt32::operator+=(int32_t value)
{
  int32_t ret = (int32_t)InterlockedExchangeAdd(&_i->_value, value);
  return (ret+value);
}

int32_t PL_AtomicInt32::operator-=(int32_t value)
{
  int32_t ret = (int32_t)InterlockedExchangeAdd(&_i->_value, -value);
  return (ret+value);
}

int32_t PL_AtomicInt32::operator=(int32_t value)
{
  _i->_value = (LONG)value;
  return (int32_t)_i->_value;
}

PL_AtomicInt32::operator int32_t() const
{
  return (int32_t)_i->_value;
}

#endif
