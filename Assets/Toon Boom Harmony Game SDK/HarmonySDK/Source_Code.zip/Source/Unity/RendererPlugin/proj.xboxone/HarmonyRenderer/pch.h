//
// pch.h
// Header for standard system include files.
//
#ifndef TARGET_PS4
#pragma once

#include <xdk.h>
#include <wrl.h>
#endif